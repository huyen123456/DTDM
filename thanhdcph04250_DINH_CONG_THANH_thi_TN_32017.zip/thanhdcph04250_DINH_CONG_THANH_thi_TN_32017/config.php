<?php

$db = new PDO('mysql:host=localhost;dbname=polybook','root','');

